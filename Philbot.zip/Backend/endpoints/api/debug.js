
async function handle() {
  // just for debugging
}

module.exports = { handle };